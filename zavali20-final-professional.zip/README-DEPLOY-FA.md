# استقرار مستقیم ZAVALI روی Cloudflare Workers

## 1) نصب Wrangler
```bash
npm install
```

## 2) ورود به Cloudflare
```bash
npx wrangler login
```

## 3) ساخت KV
اگر هنوز KV ندارید:
```bash
npx wrangler kv namespace create ZAVALI_KV
```

شناسه `id` برگشتی را در `wrangler.jsonc` به جای `REPLACE_WITH_KV_NAMESPACE_ID` قرار دهید.

## 4) بررسی تنظیمات
```bash
npx wrangler deploy --dry-run
```

## 5) Deploy
```bash
npm run deploy
```

## 6) دریافت لینک Worker
پس از Deploy، Wrangler آدرس `workers.dev` را نمایش می‌دهد.

### نکته امنیتی
هیچ API Token، رمز پنل، UUID یا Secret را داخل `worker.js` یا GitHub قرار ندهید. Secrets را با Wrangler تنظیم کنید.


## مدیریت حرفه‌ای کاربران ZAVALI20

این نسخه شامل مدیریت کاربر، محدودیت حجم، تاریخ انقضا، توکن اختصاصی اشتراک، انتخاب نوع اشتراک، Reset Traffic و تعویض توکن است.

برای Cloudflare Workers در بخش Build settings از این مقادیر استفاده کنید:
- Build command: `npm run build`
- Deploy command: `npx wrangler deploy`
- Root directory: `/`

`npm run build` ابتدا Worker را از `src` می‌سازد و نسخه نهایی را در `worker.js` و `dist/worker.js` قرار می‌دهد.

برای حفظ کاربران قبلی، همان KV Namespace فعلی پروژه را نگه دارید. مهاجرت کاربران قدیمی هنگام اولین خواندن لیست کاربران، برای آنها توکن اشتراک ایجاد می‌کند.
