# :material-cog-outline:{ .md .middle } Proxy Settings Configuration

!!! tip
    Please don't worry about incorrect configurations. There's a `Reset Settings` small button next to the `Apply Settings` button that will reset the panel to default settings.

!!! info
    You must update your subscriptions after making any changes.

<div class="grid cards" markdown>

- :material-cog-outline:{ .lg .middle } __Admin__

    ---

    Update panel, Delete panel or reset panel password.

    [:octicons-arrow-right-24: Getting started](admin-settings.md)

- :material-cog-outline:{ .lg .middle } __Telegram Bot__

    ---

    Setup Telegram bot.

    [:octicons-arrow-right-24: Getting started](telegram-bot.md)

- :material-cog-outline:{ .lg .middle } __Common__

    ---

    Configure shared settings across all protocols and subscriptions.

    [:octicons-arrow-right-24: Getting started](common.md)

- :material-cog-outline:{ .lg .middle } __VLESS - Trojan__

    ---

    Configure general VLESS and Trojan settings such as DNS Servers, Clean IPs, Ports, and more.

    [:octicons-arrow-right-24: Getting started](vless-trojan.md)

- :material-cog-outline:{ .lg .middle } __Fragment__

    ---

    Configure Fragment settings to mitigate ISP or regional disruptions.

    [:octicons-arrow-right-24: Getting started](fragment.md)

- :material-cog-outline:{ .lg .middle } __External Raw Configs__

    ---

    Add personal subscriptions and configs to Raw subscription.

    [:octicons-arrow-right-24: Getting started](external-configs.md)

- :material-cog-outline:{ .lg .middle } __Warp__

    ---

    Common Warp settings for __Warp__ and __Warp PRO__ subscriptions, including Endpoints, Scanner, IPv6, etc.

    [:octicons-arrow-right-24: Getting started](warp.md)

- :material-cog-outline:{ .lg .middle } __Warp PRO__

    ---

    PRO settings designed to bypass Warp blockage by your ISP.

    [:octicons-arrow-right-24: Getting started](warp-pro.md)

- :material-cog-outline:{ .lg .middle } __Routing Rules__

    ---

    Add routing rules to bypass local websites, block Ads, block unwanted content, and more.

    [:octicons-arrow-right-24: Getting started](routing-rules.md)

- :material-cog-outline:{ .lg .middle } __Import - Export__

    ---

    Importing or exporting panel settings via Files or links.

    [:octicons-arrow-right-24: Getting started](import-export.md)

</div>
